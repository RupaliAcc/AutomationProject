package mainPackage;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import pageObjectModule_GA.Groomauto;

public class DataDrivenFramework 
{
	public static void main(String[] args) throws Exception  
	{
		FileInputStream file = new FileInputStream("C:\\Users\\ASUS\\Desktop\\Automation Testing\\Groomauto.xlsx");
		
		XSSFWorkbook w = new XSSFWorkbook(file); 
		
		XSSFSheet s = w.getSheet("DataDriven");
		
		int size = s.getLastRowNum();
		
		System.out.println("No of Credentials: "+size);
		
		System.setProperty("webdriver.chrome.driver","C:\\Users\\Ankush\\Documents\\Automation testing\\Browser Extension\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		Thread.sleep(2000);
		
		Groomauto g = new Groomauto();
		
		g.maximizeBrowser(driver);
		Thread.sleep(2000);
		
		for(int i=1; i<=size; i++)
		{
			//Store credentials in variables
			String LoginEmail=s.getRow(i).getCell(0).getStringCellValue();
			String LoginPassword=s.getRow(i).getCell(1).getStringCellValue();
			System.out.println(LoginEmail+"\t\t"+LoginPassword);
			
			//To handle exception
			try
			{
				//Login
				g.url(driver);
				Thread.sleep(2000);
				g.login(driver);
				Thread.sleep(2000);
				g.loginEmail(driver, LoginEmail);
				Thread.sleep(2000);
				g.loginPass(driver, LoginPassword);
				Thread.sleep(2000);
				g.loginButton(driver);
				Thread.sleep(2000);

				//If credential is correct it will print valid data on console as well as in excel sheet
				System.out.println("Correct Email and password.");
				System.out.println("");
				s.getRow(i).createCell(2).setCellValue("Correct Email and password.");				
		
			}
			
			catch(Exception e)
			{
				//If Credential is incorrect it will handle by catch block and print invalid data on console as well as in excel sheet
				System.out.println("Incorrect Email and password.");
				System.out.println("");
				s.getRow(i).createCell(2).setCellValue("Incorrect Email and password.");	
			}	
		}
		//Write Data
		FileOutputStream out = new FileOutputStream("C:\\Users\\Ankush\\Documents\\Groomauto.xlsx");
		w.write(out);
	}
}
