package mainPackage;

public class Logout 
{
	public static void main(String[] args)
	{
		
	}
}
