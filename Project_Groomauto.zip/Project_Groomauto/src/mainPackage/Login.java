package mainPackage;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import pageObjectModule_GA.Groomauto;

public class Login
{
	public static void main(String[] args) throws InterruptedException
	{
		System.setProperty("webdriver.chrome.driver","C:\\Users\\Ankush\\Documents\\Automation testing\\Browser Extension\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		Thread.sleep(2000);
		
		//Create object of pom class
		Groomauto g = new Groomauto();
		
		g.maximizeBrowser(driver);
		Thread.sleep(2000);
		
		g.url(driver);
		Thread.sleep(2000);
		
		g.login(driver);
		Thread.sleep(2000);
		
		g.loginEmail(driver, "robert22@gmail.com");
		Thread.sleep(2000);
		
		g.loginPass(driver, "Pass@123");
		Thread.sleep(2000);
		
		g.loginButton(driver);
		Thread.sleep(10000);
		
		driver.navigate().back();
		Thread.sleep(5000);
	}
}
