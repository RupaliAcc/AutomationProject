package mainPackage;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

import pageObjectModule_GA.Groomauto;

public class mouseHover

{
	public static void main(String[] args) throws Exception
	{
		System.setProperty("webdriver.chrome.driver","C:\\Users\\Ankush\\Documents\\Automation testing\\Browser Extension\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		Thread.sleep(2000);
		
		//Create object of SignUp pom class
		Groomauto g = new Groomauto();
		
		g.maximizeBrowser(driver);
		Thread.sleep(2000);
		
		g.url(driver);
		Thread.sleep(2000);
		
		Actions a = new Actions(driver);
		
		List<WebElement>ls=driver.findElements(By.xpath("//ul[@class='navbar-nav']/li"));
		
		int size=ls.size();
		System.out.println("No of webelements: "+size);
		
		for(int i=1; i<=size; i++)
		{
			//Wait
			Thread.sleep(2000);
			
			//Display web-element name /html/body/div[2]/div[2]/div/nav/div/ul/li[1]
			System.out.println(driver.findElement(By.xpath("/html/body/div[2]/div[2]/div/nav/div/ul/li["+i+"]")).getText());
			
			//Perform Mouse Hover
			a.moveToElement(driver.findElement(By.xpath("/html/body/div[2]/div[2]/div/nav/div/ul/li["+i+"]"))).perform();
			Thread.sleep(2000);
		}
		
		g.closeBrowser(driver);
		
	}
}
