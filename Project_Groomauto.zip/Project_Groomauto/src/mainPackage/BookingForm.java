package mainPackage;

import java.util.Set;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import pageObjectModule_GA.Groomauto;

public class BookingForm 
{
	public static void main(String[] args) throws InterruptedException 
	{
		System.setProperty("webdriver.chrome.driver","C:\\Users\\ASUS\\Desktop\\Automation Testing\\ChromeDriver\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		Thread.sleep(2000);

		//Create object of SignUp pom class
		Groomauto g = new Groomauto();

		g.maximizeBrowser(driver);
		Thread.sleep(2000);

		g.url(driver);
		Thread.sleep(2000);

		g.login(driver);
		Thread.sleep(2000);

		g.loginEmail(driver, "robert22@gmail.com");
		Thread.sleep(2000);

		g.loginPass(driver, "Pass@123");
		Thread.sleep(2000);

		g.loginButton(driver);
		Thread.sleep(2000);

	
		
		//		si.clearname(driver);
		//		Thread.sleep(2000);

		//		si.lastName(driver, "Lee");
		//		Thread.sleep(2000);
		//		
		//		si.mobNo(driver, "9876543210");
		//		Thread.sleep(2000);
		//	

		//		si.altContactNo(driver, "9638527410");
		//		Thread.sleep(2000);
		//		
		//		si.loginEmail(driver, "robert33@gmail.com");
		//		Thread.sleep(2000);
		//		
		//		
		//		si.vehicalCom(driver, "Honda");
		//		Thread.sleep(2000);



	}
}
