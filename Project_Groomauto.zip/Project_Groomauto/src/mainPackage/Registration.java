package mainPackage;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import pageObjectModule_GA.Groomauto;

public class Registration 
{
	public static void main(String[] args) throws Exception
	{
		System.setProperty("webdriver.chrome.driver","C:\\Users\\Ankush\\Documents\\Automation testing\\Browser Extension\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		Thread.sleep(2000);
		
		//Create object of SignUp pom class
		Groomauto g = new Groomauto();
		
		g.maximizeBrowser(driver);
		Thread.sleep(2000);
		
		g.url(driver);
		Thread.sleep(2000);
		
		g.login(driver);
		Thread.sleep(2000);
		
		g.signUp(driver);
		Thread.sleep(2000);
		
		g.firstName(driver, "Robert");
		Thread.sleep(2000);
		
		g.lastName(driver, "Lee");
		Thread.sleep(2000);
		
		g.email(driver, "robert22@gmail.com");
		Thread.sleep(2000);
		
		g.mobNo(driver, "9876543210");
		Thread.sleep(2000);
		
		g.password(driver, "Pass@123");
		Thread.sleep(2000);
		
		g.repeatPassword(driver, "Pass@123");
		Thread.sleep(2000);
		
		g.regButton(driver);
		Thread.sleep(2000);
		
		g.closeBrowser(driver);
		
		
	}
}
