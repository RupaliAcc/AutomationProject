package pageObjectModule_GA;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;

public class Groomauto 
{
	public void maximizeBrowser(WebDriver driver) 
	{
		driver.manage().window().maximize();
	}
	
	public void url(WebDriver driver) 
	{
		driver.get("https://groomauto.in/");
	}
	
	public void login(WebDriver driver)
	{
		driver.findElement(By.xpath("//button[@type='button']")).click();
	}
	
	public void signUp(WebDriver driver)
	{
		driver.findElement(By.xpath("//*[@id=\"myModal\"]/div/div/div[1]/ul/li[2]/a")).click();
	}
	
	public void firstName(WebDriver driver, String fn)
	{
		driver.findElement(By.id("reg_first_name")).sendKeys(fn);
	}
	
	public void clearname(WebDriver driver)
	{
		
		driver.findElement(By.id("first_name")).clear();
	}
	
	public void lastName(WebDriver driver, String ln)
	{
		driver.findElement(By.id("reg_last_name")).sendKeys(ln);
	}
	
	public void email(WebDriver driver, String email)
	{
		driver.findElement(By.id("reg_email")).sendKeys(email);
	}
	
	public void mobNo(WebDriver driver, String mob)
	{
		driver.findElement(By.id("reg_mobile")).sendKeys("9876543210");
	}
	
	public void password(WebDriver driver, String pass)
	{
		driver.findElement(By.id("reg_password")).sendKeys(pass);
	}
	
	public void repeatPassword(WebDriver driver, String rpass)
	{
		driver.findElement(By.id("reg_rep_password")).sendKeys(rpass);
	}
	
	public void regButton(WebDriver driver)
	{
		driver.findElement(By.id("register_btn")).click();
		System.out.println("Registration Successful");
	}
	
	public void loginEmail(WebDriver driver, String ladd)
	{
		driver.findElement(By.id("login_email")).sendKeys(ladd);
	}
	
	public void loginPass(WebDriver driver, String lpass)
	{
		driver.findElement(By.id("login_password")).sendKeys(lpass);
	}
	
	public void loginButton(WebDriver driver)
	{
		driver.findElement(By.id("login_btn")).click();
	}
	
	public void altContactNo(WebDriver driver, String ano)
	{
		driver.findElement(By.id("alternate_contact")).sendKeys(ano);
	}
	
	public void vehicalCom(WebDriver driver,String com)
	{
		Select s;
		s = new Select(driver.findElement(By.id("vehicle_company")));
		s.selectByVisibleText(com);
		
	}
	
	public void window(WebDriver driver)
	{
		//getWindowHandle() >> Return Parent ID
				String ParentWindow=driver.getWindowHandle();
				System.out.println("Parent Window ID: "+ParentWindow);
	}
	public void crossbutton(WebDriver driver)
	{
		driver.findElement(By.xpath("(//button[normalize-space()='�'])[1]")).click();
	}
	
	
	public void closeBrowser(WebDriver driver)
	{
		driver.close();
	}
	
	
}
